<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="HTML5,CSS3,SASS,Bootstrap,JavaScript,Jquery">
    <meta name="author" content="ITCLAN BD" />
    <title>Romathery Home Page</title>
    <!-- Favicon -->
       <link rel="icon" href="assets/images/logo/logo.png" type="image/x-icon">
    <!--Owl Carosuel CSS-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--Ico Font-->
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
    <!--Nice Select-->
    <!-- <link rel="stylesheet" href="assets/css/nice-select.css"> -->
    <!--Main CSS-->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <header>
        <div class="ic-container">
            <div class="ic-header-warper">
                <div class="logo">
                    <a href="#"><img src="assets/images/main-logo.png" class="img-fluid" alt="logo"></a>                    
                </div>
                <div class="ic-header-menu">
                    <ul class="ic-navbar">
                        <li class="ic-nav-item"><a href="#" class="ic-nav-link">Home</a></li>
                        <!-- markup change -->
                        <li class="ic-nav-item ic-nav-dropdown">
                            <a href="#" class="ic-nav-link">warehouse management</a>
                            <ul class="ic-mega-dropdown-menu">
                                <li><a href="#">sub menu 1</a></li>
                                <li><a href="#">sub menu 2</a></li>
                                <li><a href="#">sub menu 3</a></li>
                                <li><a href="#">sub menu 4</a></li>
                                <li><a href="#">sub menu 5</a></li>
                                <li><a href="#">sub menu 6</a></li>
                                <li><a href="#">sub menu 7</a></li>
                                <li><a href="#">sub menu 8</a></li>
                                <li><a href="#">sub menu 9</a></li>
                            </ul>
                        </li>
                        <!-- markup change -->
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">Investment & Development</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">Customer Portal</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">Owner Portal</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="contact.php" class="ic-nav-link">Contact</a>
                        </li>
                    </ul>
                </div>

                <a href="#" class="ic-btn">Start free trial</a>

                

                <!--Mobile Nav start-->
                <div class="ic-mobile-menu-overlay"> </div>
                <div class="offcanvas_menu ic_mobile_nav_head">
                    <div class="container">
                        <div class="ic-mobile-menu-wrapper">
                            <div class="ic-menu-close">
                                <a href="javascript:void(0)"><i class="icofont-close-circled"></i></a>
                            </div>
                            <div id="menu" class="text-left ">
                                <ul class="ic-mobile-menu">

                                    <li class="ic-menu-item-has-children">
                                        <a href="#">Home</a>
                                    </li>

                                    <li class="ic-menu-item-has-children">
                                        <span class="menu-expand">
                                            <i class="icofont-simple-down"></i>
                                        </span>
                                        <a href="#">warehouse management</a>
                                        <ul class="ic_sub_menu" style="display: none;">
                                            <li class="menu-item-has-children">
                                                <span class="menu-expand">
                                                    <i class="icofont-simple-down"></i>
                                                </span>
                                                <a href="#">sub menu 1</a>
                                                <ul class="ic_sub_menu" style="display: none;">
                                                    <li class="ic-menu-item-has-children">
                                                        <a href="#">sub menu 1.1 </a>
                                                    </li>
                                                    <li class="ic-menu-item-has-children">
                                                        <span class="menu-expand">
                                                            <i class="icofont-simple-down"></i>
                                                        </span>
                                                        <a href="#">sub menu 1.2</a>
                                                        <ul class="ic_sub_menu" style="display: none;">
                                                            <li class="menu-item-has-children">
                                                                <span class="menu-expand">
                                                                    <i class="icofont-simple-down"></i>
                                                                </span>
                                                                <a href="#">sub menu 2.1</a>
                                                                <ul class="ic_sub_menu" style="display: none;">
                                                                    <li class="ic-menu-item-has-children">
                                                                        <a href="#">sub menu 2.1.1 </a>
                                                                    </li>
                                                                    <li class="ic-menu-item-has-children">
                                                                        <a href="#">sub menu 2.1.2</a>
                                                                    </li>                                                    
                                                                </ul>
                                                            </li>
                                                            
                                                        </ul>
                                                    </li>
                                                    <li class="ic-menu-item-has-children">
                                                        <a href="#">sub menu 1.3</a>
                                                    </li>                                                    
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>

                                    
                                    <li class="ic-menu-item-has-children"><a href="#">Investment & Development</a></li>
                                    <li class="ic-menu-item-has-children"><a href="#">Customer Portal</a></li>
                                    <li class="ic-menu-item-has-children"><a href="#">Owner Portal</a></li>
                                    <li class="ic-menu-item-has-children"><a href="#">Contact</a></li>

                                    

                                </ul>
                            </div>

                        </div>
                    </div>
                </div>

                <!--Mobile Nav End-->

                <a href="#" class="ic-mobile-menu-open">
                    <i class="icofont-navigation-menu"></i>
                </a>
            </div>
        </div>
    </header>

