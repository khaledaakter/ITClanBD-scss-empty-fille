<!--===Footer Area Start===-->

<footer class="ic-footer-area bg-blue ic-pb-60">
    <div class="ic-footer-left-shape">
        <h4 class="font-montserrat font-medium color-white ic-mb-24">Exim</h4>
        <p class="body-1 color-white ic-mb-32">Lorem ipsum dolor sit amet, conseadipiscing elit. Massa nisi, morbi magnis facilisis in erat ut. Volutpat viverra elementum sodales a vestibulum erat pellentesque.</p>
    </div>
    <div class="ic-container">
        <div class="ic-footer-warper">
            <div class="ic-footer-menu-item">
                <div class="title">
                <h4 class="font-montserrat font-medium color-white ic-mb-24">Get to Know Us</h4>
                </div>
                <div class="ic-item">
                    <ul>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Aboutv Us</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Contact Us</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Privacy Policy</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Refund Policy</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Terms and Conditions</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Air Shipping</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Ocean Shipping</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Clearing</a></li>
                        <li><a href="#" class="font-fira-sans font-regular color-white">Combine and Save</a></li>
                    </ul>
                </div>
            </div>
            <div class="ic-footer-menu-item ic-footer-last-item">
                <div class="ic-follow-us-payment">
                    <div class="left">
                        <h4 class="font-montserrat font-medium color-white ic-mb-24">Social Media Links</h4>
                        <div class="ic-item">
                            <ul class="footer-social">
                                <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                                <li><a href="#"> <i class="icofont-instagram"></i></a></li>
                            </ul>
                        </div>
                        <h4 class="font-montserrat font-medium color-white ic-mb-24">All Major Credit Cards Accepted</h4>
                    </div>

                </div>
                <div class="ic-footer-copyright">
                    <p>Copyright © 2021 <a href="#">MEGACROP 3D.</a> All Rights Reserved.
                        Design & Developed By <a href="#" target="_blank"><img src="assets/images/logo/itclan-logo.png" alt=""></a> </p>
                </div>
            </div>
        </div>
        <div class="ic-footer-copyright ic-mobile-footer-copyright">
            <p>Copyright © 2021 <a href="#">MEGACROP 3D.</a> All Rights Reserved.
                Design & Developed By <a href="#" target="_blank"><img src="assets/images/logo/itclan-logo.png" alt=""></a> </p>
        </div>
    </div>
</footer>

<!--===Footer Area End===-->


<!--===Scroll Top Area Start===-->
<!--    <a href="#" class="ic-scroll-top"><i class="icofont-rounded-up"></i></a>-->
<!--===Scroll Top Area Start===-->

<!--Jquery-->
<script src="assets/js/jquery-3.5.1.min.js"></script>
<!--Owl Carosuel Js-->
<!-- <script src="assets/js/owl.carousel.min.js"></script> -->
<!--Nice Select js-->
<!-- <script src="assets/js/wow.js"></script> -->
<!-- <script>
    new WOW().init();
</script> -->

<!-- Bootstrap Js-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- <script src="assets/js/jquery.nice-select.js"></script> -->
<!--Main Js-->
<!-- <script src="assets/js/main.js"></script> -->
<!--Custom Js-->
<script src="assets/js/custom.js"></script>
<!--Wow Js-->

</body>

</html>