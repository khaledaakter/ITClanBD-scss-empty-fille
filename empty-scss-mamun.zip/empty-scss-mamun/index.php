<?php include 'inc/header.php' ?>
<!--===Banner Area Start===-->

<section class="ic-banner-area">
    <div class="ic-banner-carousel owl-carousel">
        <div class="item">
            <div class="ic-item-count">
                <h2>01</h2>
            </div>
            <div class="ic-container">
                <div class="ic-banner-content-warper">
                    <div class="ic-banner-image">
                        <img src="assets/images/slider/slider-1.png" class="img-fluid" alt="slider1">
                    </div>
                    <div class="content">
                        <h1>High quality <span>3D printing model</span></h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque ultricpulvinar nam euismod tortor sem. Id eget orci cum senectus.</p>
                        <div class="ic-banner-btn">
                            <a href="#" class="ic-btn">Shop now <i class="flaticon-right-arrow"></i></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="ic-item-count">
                <h2>02</h2>
            </div>
            <div class="ic-container">
                <div class="ic-banner-content-warper">
                    <div class="ic-banner-image">
                        <img src="assets/images/slider/slider-1.png" class="img-fluid" alt="slider1">
                    </div>
                    <div class="content">
                        <h1>High quality <span>3D printing model</span></h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque ultricpulvinar nam euismod tortor sem. Id eget orci cum senectus.</p>
                        <div class="ic-banner-btn">
                            <a href="#" class="ic-btn">Shop now <i class="flaticon-right-arrow"></i></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="ic-item-count">
                <h2>03</h2>
            </div>
            <div class="ic-container">
                <div class="ic-banner-content-warper">
                    <div class="ic-banner-image">
                        <img src="assets/images/slider/slider-1.png" class="img-fluid" alt="slider1">
                    </div>
                    <div class="content">
                        <h1>High quality <span>3D printing model</span></h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque ultricpulvinar nam euismod tortor sem. Id eget orci cum senectus.</p>
                        <div class="ic-banner-btn">
                            <a href="#" class="ic-btn">Shop now <i class="flaticon-right-arrow"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</section>

<!--===Banner Area End===-->


<!--===Why Buy Area Start===-->

<section class="ic-why-buy-area">
    <div class="ic-container">
        <div class="row">
            <div class="col-md-3">
                <div class="ic-why-buy-left-content">

                </div>
            </div>
        </div>
    </div>
</section>

<!--===Why Buy Area End===-->



<!--===Footer Area Start===-->



<!--===Footer Area End===-->

<?php include 'inc/footer.php'  ?>