<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="HTML5,CSS3,SASS,Bootstrap,JavaScript,Jquery">
    <meta name="author" content="ITCLAN BD" />
    <title>3D Print-Home Page</title>
    <!-- Favicon -->
    <!--    <link rel="icon" href="assets/images/icon/favicon.png" type="image/x-icon">-->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--Ico Font-->
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
    <!--Nice Select-->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!--Owl Carosuel CSS-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <!--Animated Css-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--Main CSS-->
    <link rel="stylesheet" href="assets/css/style.css">
    <!--Custom CSS-->
    <link rel="stylesheet" href="assets/css/custom.css">
</head>

<body>

    <!--===Header Area Start===-->

    <header>
        <div class="ic-container">
            <div class="ic-header-warper">
                <div class="logo">
                    <img src="assets/images/logo/logo.png" class="img-fluid" alt="logo">
                </div>
                <div class="ic-header-menu">
                    <ul class="ic-navbar">
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">3D printing model</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">Store</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">ABOUT us</a>
                        </li>
                        <li class="ic-nav-item">
                            <a href="#" class="ic-nav-link">Contact us</a>
                        </li>
                    </ul>
                </div>
                <div class="ic-menu-right-icon">
                    <a href="#"><i class="flaticon-search"></i></a>
                    <a href="#"><i class="flaticon-user"></i></a>
                    <a href="#" class="ic-cart">
                        <span class="ic-total-cart">01</span>
                        <i class="flaticon-shopping-bag"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!--===Header Area End===-->