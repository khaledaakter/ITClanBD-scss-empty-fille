<!--===Scroll Top Area Start===-->
<!--    <a href="#" class="ic-scroll-top"><i class="icofont-rounded-up"></i></a>-->
<!--===Scroll Top Area Start===-->

<!--Jquery-->
<script src="assets/js/jquery-3.5.1.min.js"></script>
<!--Bootstrap Js-->
<script src="assets/js/bootstrap.min.js"></script>
<!--Owl Carosuel Js-->
<script src="assets/js/owl.carousel.min.js"></script>
<!--Nice Select js-->
<script src="assets/js/jquery.nice-select.js"></script>
<!--Main Js-->
<script src="assets/js/main.js"></script>
<!--Custom Js-->
<script src="assets/js/custom.js"></script>
<!--Wow Js-->
<script src="assets/js/wow.js"></script>
<script>
    new WOW().init();
</script>

</body>

</html>